package frost.com.htvchallenge.retrofit;

import android.support.v4.BuildConfig;

import frost.com.htvchallenge.ResponseModel;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

/**
 * Created by chinmayghag on 10/02/18.
 */

public interface RetofitAPIClient {

    String BASE_URL = "http://146.148.111.64";

    Retrofit retrofit = new Retrofit.Builder()
            .baseUrl(RetofitAPIClient.BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build();


//    @FormUrlEncoded
    @Multipart
    @POST("/issue")
    Call<ResponseModel> sendDeviceId(@Part MultipartBody.Part filePart,
                                    @Part("fcmtoken") RequestBody fcmKey,
                                    @Part("lat") RequestBody lat,
                                    @Part("lng") RequestBody lng);


}
