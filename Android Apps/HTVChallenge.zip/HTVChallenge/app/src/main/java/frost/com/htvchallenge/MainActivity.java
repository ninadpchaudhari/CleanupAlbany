package frost.com.htvchallenge;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import frost.com.htvchallenge.retrofit.RetofitAPIClient;
import frost.com.htvchallenge.sharePreferences.AppPreferenceUtils;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private static final int REQUEST_IMAGE_CAPTURE = 101;
    ImageView imgvPicture;
    Button btnSend;
    private String filename = "hack";
    private File f;
    AppPreferenceUtils prefs;

    public final int MY_REQUEST__CODE = 100;
    protected Location mLocation;
    private FusedLocationProviderClient mFusedLocationClient;
//    private boolean camShouldBeLaunchedOrNo;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgvPicture = (ImageView)findViewById(R.id.imgv_preview);
        btnSend = (Button)findViewById(R.id.btn_send);
        btnSend.setOnClickListener(this);
        prefs = new AppPreferenceUtils(getApplicationContext());
        if (ActivityCompat.checkSelfPermission(MainActivity.this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(MainActivity.this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }else{
            mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
            mFusedLocationClient.getLastLocation()
                    .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            // Got last known location. In some rare situations this can be null.
                            if (location != null) {
                                // Logic to handle location object
                                mLocation = location;
                            }
                        }
                    });
        }

        capturePhoto();

    }


    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_send:
                sendPhotoToServer();
                break;
        }
    }

    private void capturePhoto() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            // only for gingerbread and newer versions
            String permission = android.Manifest.permission.CAMERA;
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{android.Manifest.permission.CAMERA,
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.READ_EXTERNAL_STORAGE},
                        MY_REQUEST__CODE);
            } else {
                if (getApplicationContext().getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_CAMERA)) {
                    Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                    }

                }
            }
        } else {
            if (getApplicationContext().getPackageManager().hasSystemFeature(
                    PackageManager.FEATURE_CAMERA)) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                }

            }
        }
    }

    private void sendPhotoToServer(){
//        Log.i("frost", "sendPhotoToServer: "+mLocation.getLatitude());


        MultipartBody.Part filePart = MultipartBody.Part.createFormData("file", f.getName(),
                RequestBody.create(MediaType.parse("image/*"), f));
//        if(prefs != null && mLocation != null) {
            RequestBody fcmKey = RequestBody.create(MediaType.parse("text/plain"), prefs.getRegId());
            RequestBody lat = RequestBody.create(MediaType.parse("text/plain"), mLocation.getLatitude() + "");
            RequestBody lng = RequestBody.create(MediaType.parse("text/plain"), mLocation.getLongitude() + "");


            RetofitAPIClient retofitAPIClient = RetofitAPIClient.retrofit.create(RetofitAPIClient.class);
            Call<ResponseModel> registerDeviceCall = retofitAPIClient.sendDeviceId(filePart, fcmKey, lat, lng);

            registerDeviceCall.enqueue(new Callback<ResponseModel>() {
                @Override
                public void onResponse(Call<ResponseModel> call, Response<ResponseModel> response) {
                    ResponseModel responseModel = response.body();
//                    Log.i("frost", "onResponse: "+responseModel.getResponse());
                    if(response.isSuccessful()){
                        Toast.makeText(MainActivity.this, "Thank you for your report", Toast.LENGTH_SHORT).show();
                        finish();
                    }else{
                        Toast.makeText(MainActivity.this, "Something Went Wrong, Can you send one more image?", Toast.LENGTH_SHORT).show();
                        capturePhoto();
                    }

                }

                @Override
                public void onFailure(Call<ResponseModel> call, Throwable t) {
                    Log.i("frost", "onResponse: Failed " + t.getMessage());
                }
            });
        }/*else{
            Log.i("frost", "sendPhotoToServer: ");
        }*/

//    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Log.i("frost", "onActivityResult: ");
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            Log.i("frost", "onActivityResult: "+imageBitmap);
            imgvPicture.setImageBitmap(imageBitmap);

            f = new File(getApplicationContext().getCacheDir(), filename);
            try {
                f.createNewFile();
                Bitmap bitmap = imageBitmap;
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 0 /*ignored for PNG*/, bos);
                byte[] bitmapdata = bos.toByteArray();
                FileOutputStream fos = new FileOutputStream(f);
                fos.write(bitmapdata);
                fos.flush();
                fos.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
            btnSend.setEnabled(true);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case MY_REQUEST__CODE:
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_DENIED){
                    Toast.makeText(this,"Sorry Couldn't proceed withoug this persmission",Toast.LENGTH_SHORT).show();
                    finish();
                }else{
                    if (getApplicationContext().getPackageManager().hasSystemFeature(
                            PackageManager.FEATURE_CAMERA)) {
                        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                        }

                    }
                }
                break;
            case 1:
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_DENIED){
                    Toast.makeText(this,"Sorry Couldn't proceed withoug this persmission",Toast.LENGTH_SHORT).show();
                    finish();
                }else{
                    capturePhoto();
//                    camShouldBeLaunchedOrNo = true;
                    return;
                }

                break;
        }
    }
}
