package frost.com.htvchallenge;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by chinmayghag on 10/02/18.
 */

public class ResponseModel {
    @SerializedName("status")
    @Expose
    private String response;


    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }
}
